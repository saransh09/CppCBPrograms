#include<iostream>
using namespace std;
char * getCharacterArray() {
    char p[] = "CODING BLOCKS";
    return p;
}
int main() {
    cout << getCharacterArray();
    return 0;
}
