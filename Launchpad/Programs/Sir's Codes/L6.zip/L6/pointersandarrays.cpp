#include<iostream>
using namespace std;
void func(int arr[]) {
    cout << arr << endl;
    cout << &arr << endl;
//    cout << sizeof(arr) << endl;
    return;
}
void func2(int * arr) {
    cout << arr << endl;
    cout << sizeof(arr) << endl;
    return;
}
int * fun2() {
    int arr[] = {1,2,3};
    cout << arr << endl;
    return arr;
}
int main() {
    int * ptr = fun2();
    cout << ptr << endl;
    cout << *ptr << endl;
    return 0;
    /*
    int arr[] = {1,2,3,4,5};
    cout << arr << endl;
    cout << sizeof(arr) << endl;
    func(arr);*/
    /*
    cout << arr << endl;
    cout << *(arr+0) << endl;
    cout << *(arr+2) << endl;
    cout << *(arr+ 10) << endl;*/
    return 0;
}
