#include<iostream>
using namespace std;
int length(char * str) {
    int i = 0; 
    for(;*(str+i)!='\0';i++) {}
    return i;
}
void stringcopy(char * dest, char * src) {
    int i = 0; 
    while (str[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0'; // dest[i] = 0;

}
int main() {
    char str[100], longest[100];
    int N, longestlength = 0;
    cin >> N;
    cin.get();
    cin.getline(longest, 100);
    longestlength = length(longest);
    for (int i = 0; i < N-1;i++) {
        cin.getline(str, 100);
        int len = length(str);
        if (len > longestlength) {
            longestlength = len;
            stringcopy(longest, str);
        }
    }
    cout << "Longest string is " << longest << endl;
}
