#include<iostream>
using namespace std;
int main() {
    int arr[10] = { 1,2,3,34,4,4,4,5,6,9};
    int B[] = {1,2,3};
//    int C[3] = {1,3,3,4,5};
    int D[4] = {0};
    cout << D[0] << " " << D[1] << " " << D[2] << " " << D[3] << endl;
    return 0;
}
