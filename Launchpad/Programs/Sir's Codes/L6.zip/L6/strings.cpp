#include<iostream>
using namespace std;
int length(char * str) {
    int i = 0;
    while(str[i] != '\0') { // while(*(str+i) != '\0') {

        i++;
    }
    return i;
}
bool isPalindrome(char * str) {
    int i = 0; 
    int j = length(str) -1;
    while (i < j) {
        if (str[i] != str[j]) {
            return false;
        }
        i++;
        j--;
    }
    return true;
}
void readline(char * address, int size) {
    char ch = cin.get();
    int i = 0;
    while(i< size-1 && ch != '\n') {
        *(address+i) = ch;
        i++;
        ch = cin.get();
    }
    address[i] = '\0';
    return;
}
int main() {
    char str[100];
    cin.getline(str, 100);
    cout << "Length of string is" << length(str) << endl;
    return 0;
}
