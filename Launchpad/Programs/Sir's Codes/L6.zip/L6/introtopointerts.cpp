#include<iostream>
using namespace std;
void dummy(int *b) {
    *b = 10;
    return;
}
void anotherfunciton(int * ptr, int c) {
    cout << ptr << endl;
    cout << &c << endl;
    ptr = &c;
    *ptr = 100;
    cout << ptr << endl;
    cout << c << endl;
    return;
}
void swap(int* a, int *b) {
    int temp = *a; 
    *a = *b;
    *b = temp;
}
int main() {
    int x = 5, y = 7;
    swap(&x,&y);
    cout << x << " " << y << endl;
    /*anotherfunciton(&x, y);
    cout << &x << endl;
    cout << &y << endl;
    cout << x << endl;
    cout << y << endl;
*/
    /*
    int x = 4;
    dummy(&x);
    cout << x << endl;
    x = 50;
    int *ptr = &x;
    dummy(ptr);
    cout << x << endl;
    cout << *ptr << endl;
*/
/*    int * y;
    y = &x;
    (*y)++;
    cout << x << endl;
    cout << &x << endl;
    cout << y << endl;
    cout << &y << endl;
    cout << *y << endl;
*/
/*    int x = 10;
    int y = 20;
    cout << (&x) << endl;
    cout << &(++x) << endl;
    *(&x) = 100;
    cout << x << endl;*/
//    cout << &(x++) << endl;
//    cout << &(10) << endl;
//    cout << &(x+y) << endl;
    return 0;
}
