#include<iostream>
using namespace std;
int sumofArray(int * arr, int N) {
    int sum = 0;
    for(int i =0 ; i < N; i++) {
        sum = sum+ arr[i];
    }
    return sum;
}
int main() {
    int mat[100][100];
    int N, M;
    cout << "Enter number of rows ";
    cin >> N;
    cout << "Enter number of columns ";
    cin >> M;
    int i, j;
    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            cin >> mat[i][j];
        }
    }
    int maxrowsum = 0; 
    int maxrowvalue = sumofArray(arr[0], M);
    for (i = 1; i < N; i++) {
        int sum = sumofArray(arr[i], M);
        if (sum > maxrowsum) {
            maxrowsum = sum;
            maxrowvalue = i;
        }
    }



    return 0;
}
