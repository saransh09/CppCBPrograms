#include<iostream>
using namespace std;
int main() {
    int arr[4];
    cout << &arr << endl;
    cout << arr << endl;
    cout << &arr[0] << endl;
    cout << &arr+1 << endl;
    cout << arr+1 << endl;
    cout << &arr[0] + 1 << endl;
    return 0;
}
