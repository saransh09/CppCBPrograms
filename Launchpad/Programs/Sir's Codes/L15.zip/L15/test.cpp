#include<iostream>
using namespace std;
int main() {
    int a = 5;
    int b = 3;
    (a=b)++;
    cout << a << endl;
    cout << b << endl;
//    cout << (~a) << endl;
 //   cout << a << endl;
    return 0;
}
