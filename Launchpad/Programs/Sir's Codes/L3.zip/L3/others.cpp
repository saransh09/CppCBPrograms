#include<iostream>
using namespace std;
int main() {
    int a = 10;
    sizeof(a);
    sizeof(int);
    cout << sizeof(int) << endl;
    cout << sizeof(long int) << endl;
    cout << sizeof(char) << endl;
    cout << sizeof(long long int) << endl;
    cout << (char)(97 + (char)true)<< endl;
    return 0;
}
