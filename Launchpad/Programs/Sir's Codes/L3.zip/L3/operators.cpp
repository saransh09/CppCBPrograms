#include<iostream>
using namespace std;
int main() {
    cout << (5 & 4) << endl;
    cout << (5 | 9) << endl;
    cout << (5 ^ 3) << endl;
    cout << (~5) << endl;
    cout << (4 << 3) << endl;
    cout << (4 >> 2) << endl;
/*    int a = 10;
    int c = a++;
    int d = ++a;
    cout << c << endl;
    cout << d << endl;
    cout << a << endl;
    (1 || (++a));
    cout << a << endl;
    (0 || (++a));
    cout << a << endl;*/
    return 0;
}
