#include<iostream>
using namespace std;
int main() {
    int N;
    cin >> N;
    int i, j;
    for(i = 2; i <= N ; i = i+1) {
        for( j = 2; j < i; j++) {
            if (i % j == 0) {
                break;
            }
        }
        if (j == i) {
            cout << i << " ";
        }
    }
    cout << endl;
    return 0;
}
